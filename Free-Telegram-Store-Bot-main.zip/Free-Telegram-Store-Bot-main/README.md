# Free-Telegram-Store-Bot
I made this Bot Free 100%.

The Telegram Store Bot you can use for selling and managing your products, services, and orders. 

![image1](https://i.ibb.co/6tvrHzH/v5-1.png)


# Message me at [@InDMDev](https://t.me/InDMDev) for your advanced Bots customizations.


For more Bots like this, and to be the first to know when I publish free bots, join my channel: [@InDMDevBots](https://t.me/InDMDevBots)


# Guide
1. Install Python 3.10
2. Install any git version
3. Open terminal
4. Run this command in your terminal "git clone https://github.com/indmdev/Free-Telegram-Store-Bot.git"
5. Run this command in your terminal "cd Free-Telegram-Store-Bot-main"
6. Run this command in your terminal: "pip install -r requirements.txt"
7. Set up a free NGROK account at https://ngrok.com
8. Open another terminal and run your Ngrok
9. Setup your new Bot at [@BotFather](https://t.me/Botfather)
10. Open the config.env file
11. Add your Bot Token (Provided to you by [@BotFather](https://t.me/Botfather))
12. Add your Ngrok URL
13. Add your Store Currency
14. Save and close the file
16. Run the "python store_main.py" command in your terminal from the "Free-Telegram-Store-Bot-main" folder
17. Completed



# Upgraded version of this FREE Bot 👉: [@InDMShopV5Bot](https://t.me/inDMShopV5Bot)

# [Our Classic Bot Features:](https://i.ibb.co/6tvrHzH/v5-1.png)

# Test and Subscribe To Classic Bot 👉 [@InDMShopBot](https://t.me/InDMShopBot) [Check Demo](https://t.me/InDMMarketbot)



# Version 6 coming soon 👇:
![photo_2025-09-10 08 21 53](https://i.ibb.co/8mhDS9F/v5-2.png)

# Languages in version 6 coming soon 👇:
![photo_2025-09-10 08 21 53](https://i.ibb.co/d54nQJ7/v5-3.png)



🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨
# Note: Use this program only for legal purposes, InDMDev is not and will not be responsible for any illegal activity/activities you indulge in using this program.
🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨


# MAKE THE WORLD A BETTER PLACE 🙏
